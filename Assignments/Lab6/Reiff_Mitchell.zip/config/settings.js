// I pledge my honor that I have abided by the Stevens Honor System.

// You will need to change the DB name to match the required DB name in the assignment specs!
export const mongoConfig = {
  serverUrl: "mongodb://localhost:27017/",
  database: "Mitchell_Reiff_lab6",
};
