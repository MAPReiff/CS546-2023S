//YOU WILL NEED TO CHANGE THE DB NAME TO MATCH THE REQUIRED DB NAME IN THE ASSIGNMENT SPECS!!!

export const mongoConfig = {
  serverUrl: 'mongodb://localhost:27017/',
  database: 'Mitchell_Reiff_lab10'
};
